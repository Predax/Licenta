-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 26 Iun 2017 la 22:19
-- Versiune server: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `deton`
--

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `accounts`
--

CREATE TABLE `accounts` (
  `Username_id` int(7) NOT NULL,
  `Number` varchar(16) NOT NULL DEFAULT '0000000000000000',
  `Money` int(9) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Salvarea datelor din tabel `accounts`
--

INSERT INTO `accounts` (`Username_id`, `Number`, `Money`) VALUES
(0, '0000000000000000', 0),
(9, '1000000000000007', 15000),
(10, '5876586660002268', 900),
(24, '0000000000000000', 0),
(25, '6548768975578555', 2550),
(26, '1234567891478958', 600),
(31, '0000000000000000', 0),
(32, '0000000000000000', 0),
(33, '0000000000000000', 0),
(34, '0000000000000000', 0);

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `county`
--

CREATE TABLE `county` (
  `Id` int(5) NOT NULL,
  `Name` varchar(45) NOT NULL,
  `Value` int(10) NOT NULL,
  `Resource` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Salvarea datelor din tabel `county`
--

INSERT INTO `county` (`Id`, `Name`, `Value`, `Resource`) VALUES
(1, 'Iasi', 0, 1),
(2, 'Neamt', 200, 2),
(3, 'Botosani', 200, 2),
(4, 'Vaslui', 200, 2),
(5, 'Bacau', 250, 3),
(6, 'Suceva', 250, 3),
(7, 'Harghita', 350, 4),
(8, 'Covasna', 350, 4),
(9, 'Vrancea', 350, 4),
(10, 'Galati', 350, 4);

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `date_resource`
--

CREATE TABLE `date_resource` (
  `Schedule_date` date NOT NULL,
  `Total_resource` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Salvarea datelor din tabel `date_resource`
--

INSERT INTO `date_resource` (`Schedule_date`, `Total_resource`) VALUES
('2017-06-17', 8),
('2017-06-18', 8),
('2017-06-19', 8),
('2017-06-20', 8),
('2017-06-21', 7),
('2017-06-22', 4),
('2017-06-23', 5),
('2017-06-24', 8),
('2017-06-25', 11),
('2017-06-26', 8),
('2017-06-27', 10),
('2017-06-28', 8),
('2017-06-29', 9);

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `messages`
--

CREATE TABLE `messages` (
  `Message_id` int(11) NOT NULL,
  `Subject` varchar(45) NOT NULL DEFAULT 'no_subject',
  `Content` text NOT NULL,
  `Username` varchar(25) NOT NULL,
  `Date_reception` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Salvarea datelor din tabel `messages`
--

INSERT INTO `messages` (`Message_id`, `Subject`, `Content`, `Username`, `Date_reception`) VALUES
(13, 'Ola', 'Facem inca un test', 'ionutPreda', '2017-05-20'),
(14, 'Salut', 'Sunt super multumit de aplicatia dumneavoastra! ', 'new000', '2017-06-21'),
(15, 'Hello', 'I need to know if you can also create a building. Thank you!', 'new123', '2017-06-21'),
(16, 'Intrebare', 'Pot face 2 cereri in aceeasi zi?', 'ionutPreda', '2017-06-22');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `processing`
--

CREATE TABLE `processing` (
  `Id` int(11) NOT NULL,
  `Type` varchar(25) NOT NULL,
  `Cost` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Salvarea datelor din tabel `processing`
--

INSERT INTO `processing` (`Id`, `Type`, `Cost`) VALUES
(1, 'Normal', 0),
(2, 'Quick', 100),
(3, 'Urgent', 250);

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `requests`
--

CREATE TABLE `requests` (
  `Request_id` int(7) NOT NULL,
  `Username_id` int(10) NOT NULL,
  `Service` varchar(75) NOT NULL,
  `Processing` varchar(20) NOT NULL,
  `County` varchar(45) NOT NULL,
  `CityTown` varchar(45) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Other` varchar(100) DEFAULT NULL,
  `Username` varchar(50) NOT NULL,
  `Date` date NOT NULL,
  `Sum_total` int(7) NOT NULL,
  `Status` varchar(1) NOT NULL DEFAULT 'P',
  `Resource` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Salvarea datelor din tabel `requests`
--

INSERT INTO `requests` (`Request_id`, `Username_id`, `Service`, `Processing`, `County`, `CityTown`, `Address`, `Other`, `Username`, `Date`, `Sum_total`, `Status`, `Resource`) VALUES
(5, 19, 'Terrain outside the city', 'Quick', 'Suceva', 'Iacobeni', 'Str noua, 1, aa', '', 'gigi', '2017-09-06', 1300, 'N', 3),
(15, 19, 'Land inside', 'Normal', 'Neamt', 'Piatra Neamt', 'str Mihai Eminescu,3', '', 'gigi', '2017-06-22', 650, 'N', 2),
(16, 26, 'Personal measeurement', 'Urgent', 'Vaslui', 'dddd', 'ddddd', '', 'new000', '2017-06-22', 1900, 'N', 2),
(17, 26, 'House measeurement', 'Urgent', 'Suceva', 'ffff', 'aaaaa', '', 'new000', '2017-06-21', 1100, 'N', 3),
(18, 26, 'Personal measeurement', 'Normal', 'Covasna', 'Targu secuiesc', 'aaa, poarta veche', '', 'new000', '2017-06-22', 700, 'N', 4),
(19, 25, 'Personal measeurement', 'Urgent', 'Iasi', 'Iasi', 'Blvd. ACB, nr 11', '', 'new123', '2017-06-22', 600, 'N', 1),
(20, 26, 'Land inside', 'Urgent', 'Neamt', 'Targu neamt', 'Strada noua, toma', '', 'new000', '2017-06-22', 900, 'N', 2),
(21, 26, 'Personal measeurement', 'Normal', 'Iasi', 'dddd', 'aaaa', '', 'new000', '2017-06-21', 350, 'N', 1),
(22, 26, 'Personal measeurement', 'Normal', 'Iasi', 'ffcgf', 'vgvfvg', '', 'new000', '2017-06-21', 350, 'N', 1),
(23, 26, 'Personal measeurement', 'Normal', 'Iasi', 'fffff', 'fffff', '', 'new000', '2017-06-25', 350, 'Y', 1),
(25, 26, 'Land inside', 'Normal', 'Iasi', 'ggg', 'ggg', '', 'new000', '2017-06-23', 450, 'N', 1),
(26, 26, 'Personal measeurement', 'Normal', 'Iasi', 'ddddd', 'ddddd', '', 'new000', '2017-06-25', 350, 'Y', 1),
(27, 26, 'Land inside', 'Normal', 'Iasi', 'zxc', 'zxczxc', '', 'new000', '2017-06-22', 450, 'N', 1),
(28, 26, 'House measeurement', 'Quick', 'Iasi', 'aa', 'sasdas', '', 'new000', '2017-06-25', 700, 'Y', 1),
(29, 25, 'Terrain outside the city', 'Urgent', 'Galati', 'Tecuci', 'Strada Bisericii, nr 24', '', 'new123', '2017-06-24', 1550, 'N', 4),
(30, 25, 'Personal measeurement', 'Normal', 'Iasi', 'Iasi', 'ACB, nr 22', '', 'new123', '2017-06-25', 350, 'N', 1),
(31, 26, 'Marking private property limit', 'Quick', 'Botosani', 'Botosani', 'strada 2', '', 'new000', '2017-06-25', 1100, 'Y', 2),
(32, 26, 'House measeurement', 'Normal', 'Iasi', 'Iasi', 'Dacia, nr 21', '', 'new000', '2017-06-27', 600, 'P', 1),
(33, 10, 'House measeurement (planning construction)', 'Urgent', 'Galati', 'Pechea', 'Soseaua Principala, 678', '', 'ionutPreda', '2017-06-27', 2600, 'P', 6),
(34, 26, 'Personal measeurement', 'Quick', 'Neamt', 'Piatra Neamt', 'Strada veche, nr 45', '', 'new000', '2017-06-27', 650, 'P', 2);

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `services`
--

CREATE TABLE `services` (
  `Service_id` int(7) NOT NULL,
  `Service_name` varchar(75) NOT NULL,
  `Cost` bigint(15) NOT NULL,
  `Resource` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Salvarea datelor din tabel `services`
--

INSERT INTO `services` (`Service_id`, `Service_name`, `Cost`, `Resource`) VALUES
(1, 'Please select', 0, 0),
(2, 'Personal measeurement', 350, 0),
(3, 'House measeurement', 600, 0),
(4, 'Land inside', 450, 0),
(5, 'Terrain outside the city', 950, 0),
(6, 'Marking private property limit', 800, 0),
(7, 'House measeurement (planning construction)', 2000, 2),
(8, 'Road measeurement (small) (planning construction)', 5000, 4);

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `users`
--

CREATE TABLE `users` (
  `Id` int(7) NOT NULL,
  `Username` varchar(25) NOT NULL,
  `Firstname` varchar(25) DEFAULT NULL,
  `Surname` varchar(25) DEFAULT NULL,
  `Password` varchar(25) NOT NULL,
  `Phone` varchar(15) DEFAULT NULL,
  `Email` varchar(35) DEFAULT NULL,
  `Age` int(2) DEFAULT NULL,
  `Sex` varchar(1) DEFAULT NULL,
  `Role` varchar(3) NOT NULL DEFAULT 'USR',
  `Image` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Salvarea datelor din tabel `users`
--

INSERT INTO `users` (`Id`, `Username`, `Firstname`, `Surname`, `Password`, `Phone`, `Email`, `Age`, `Sex`, `Role`, `Image`) VALUES
(9, 'ionut', 'Ionut', 'Preda', '12345', '0726586834', 'preda.ionut.iulian@gmail.com', 22, 'M', 'ADM', 'IMG_0812_new.JPG'),
(25, 'new123', 'Andrei', 'Apostol', '12345', '0758963564', 'cosminaloredana20@gmail.com', 27, 'M', 'USR', ''),
(26, 'new000', 'Ilie', 'Moromete 2', '12345', '0759580258', 'cosminaloredana20@gmail.com', 56, 'M', 'USR', '18009365_771816802982753_784238407_n.jpg'),
(27, 'test', 'Alin', 'Andrei', '12345', '0758967526', 'probets1x2@yahoo.com', 29, 'M', 'USR', ''),
(28, 'bunny', 'Dorin', 'Goian', '12345', '0789454321', 'probets1x2@yahoo.com', 34, 'M', 'USR', NULL),
(31, 'reraa', 'asdasd', 'asdasd', '12323', 'asdds', 'sw33t_lov3r15@yahoo.com', 22, 'M', 'USR', NULL),
(32, 'aldo', 'Adrian', 'Grigurescu', '12345', '0758967526', 'sdfsd@asdka.com', 45, 'M', 'USR', NULL),
(34, 'lucian', 'Adelin', 'Popescu', '11111', '0758987456', 'adelin@yahoo.com', 56, 'M', 'USR', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`Username_id`);

--
-- Indexes for table `county`
--
ALTER TABLE `county`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `date_resource`
--
ALTER TABLE `date_resource`
  ADD PRIMARY KEY (`Schedule_date`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`Message_id`);

--
-- Indexes for table `processing`
--
ALTER TABLE `processing`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`Request_id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`Service_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `county`
--
ALTER TABLE `county`
  MODIFY `Id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `Message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `processing`
--
ALTER TABLE `processing`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `Request_id` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `Service_id` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `Id` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
